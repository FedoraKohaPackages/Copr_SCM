package SMS::Send::BAD2;

use strict;

use vars qw{$VERSION};
BEGIN {
	$VERSION = '0.01';
}

sub new { bless {}, shift }

1;
