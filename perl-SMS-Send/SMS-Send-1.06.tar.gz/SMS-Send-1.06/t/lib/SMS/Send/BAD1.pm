package SMS::Send::BAD1;

use strict;

use vars qw{$VERSION};
BEGIN {
	$VERSION = '0.01';
}

die "Dying with A SPECIFIC ERROR";

1;
