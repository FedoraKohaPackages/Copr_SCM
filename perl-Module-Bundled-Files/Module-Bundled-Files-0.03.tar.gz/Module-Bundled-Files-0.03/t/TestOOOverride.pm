#!/usr/bin/perl -w
package TestOOOverride;
use strict;

use base 'TestOO';

1;