#!/usr/bin/perl -w
package TestNonOOOverride;
use strict;

use base 'TestNonOO';

1;