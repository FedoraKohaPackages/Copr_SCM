package Catmandu::Fix::undef_error;

use Moo;

sub fix {
    undef;
}

1;
