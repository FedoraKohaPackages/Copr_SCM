package Catmandu::Expander;

use Catmandu::Sane;

our $VERSION = '1.0304';

use parent 'CGI::Expand';

sub max_array {1000000}

1;

