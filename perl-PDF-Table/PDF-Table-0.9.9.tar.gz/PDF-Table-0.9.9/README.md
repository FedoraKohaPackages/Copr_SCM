PDF-Table
=========

Official repository for PDF::Table module collaboration.

https://github.com/kamenov/PDF-Table.git

Any patches, pull requests, issues and feedback are more than welcome!

=======================
SOME NOTES

This module creates text blocks and tables into PDF documents using PDF::API2 Perl module.

CHANGES

To see a list of changes do one or more of the following:

Read the Changes file

Review commits history on GitHub

Make a diff from the tools menu at CPAN

CONTACTS 

@deskata on Twitter 

Use the issue tracker on GitHub

See http://search.cpan.org/~omega/

See http://search.cpan.org/~jbazik/

INSTALLATION

To install this module type the following:

   perl Makefile.PL
   make
   make test
   make install

DEPENDENCIES

This module requires these other modules and libraries:

  PDF::API2

COPYRIGHT AND LICENCE

Copyright (C) 2006 by Daemmon Hughes

Extended by Desislav Kamenov since version 0.02

This library is free software; you can redistribute it and/or modify
it under the same terms as Perl itself, either Perl version 5.8.7 or,
at your option, any later version of Perl 5 you may have available.


