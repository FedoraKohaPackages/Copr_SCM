package TestData;
use strict;
use warnings;

our %test = ( a => 1 );

our %required = (
    x       => 10,
    w       => 300,
    start_y => 700,
    next_y  => 600,
    start_h => 100,
    next_h  => 500,
);

return 1;
