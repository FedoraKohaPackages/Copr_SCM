package Monkey::D;

sub new { bless {}, $_[0] }

sub meth_d { 'in Monkey::D meth_d' }

1;
