package Monkey::False;

# This does not end in a true value, so `require`-ing it will fail.
