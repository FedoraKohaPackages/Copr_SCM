package Monkey::Invalid;

# This is a syntax error:
'one term'
'then another';

1;
