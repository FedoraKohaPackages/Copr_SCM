package Monkey::C;

use base qw<Monkey::A>;

1;
